//Find the roots of a quadratic equation.
#include <stdio.h>
#include <math.h>

int main() {
    float a, b, c, D, root1, root2, real, imag;

    printf("Enter coefficients a, b and c: ");
    scanf("%f %f %f", &a, &b, &c);

    D = (b * b) - (4 * a * c);

    if (D > 0) {
        root1 = (-b + sqrt(D)) / (2 * a);
        root2 = (-b - sqrt(D)) / (2 * a);

        printf("Root1 = %.2f\n", root1);
        printf("Root2 = %.2f\n", root2);
    }
    else if (D == 0) {
        root1 = root2 = -b / (2 * a);

        printf("Root1 = Root2 = %.2f\n", root1);
    }
    else {
        real = -b / (2 * a);
        imag = sqrt(-D) / (2 * a);

        printf("Root1 = %.2f + %.2fi\n", real, imag);
        printf("Root2 = %.2f - %.2fi\n", real, imag);
    }

    return 0;
}